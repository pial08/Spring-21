Code for The Annotated Transformer blog post:

http://nlp.seas.harvard.edu/2018/04/03/attention.html
